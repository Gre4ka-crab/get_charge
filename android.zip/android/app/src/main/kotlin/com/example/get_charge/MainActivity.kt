package com.example.get_charge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
